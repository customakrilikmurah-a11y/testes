/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy,
  addDoc,
  serverTimestamp,
  doc,
  setDoc,
  deleteDoc,
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { auth, db, loginWithCode, signOut, Room, roomConverter } from '@/src/lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageSquare, 
  Plus, 
  LogOut, 
  Send, 
  Hash, 
  User as UserIcon,
  ChevronRight,
  Loader2,
  Trash2,
  Smile,
  ShieldCheck,
  KeyRound
} from 'lucide-react';
import { format } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Button = ({ 
  className, 
  variant = 'primary', 
  size = 'md',
  ...props 
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { 
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline',
  size?: 'sm' | 'md' | 'lg'
}) => {
  const variants = {
    primary: 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md',
    secondary: 'bg-gray-800 text-white hover:bg-gray-900 shadow-sm',
    ghost: 'bg-transparent text-gray-400 hover:bg-gray-100',
    outline: 'border border-gray-200 text-gray-800 hover:bg-gray-50',
    danger: 'bg-red-50 text-red-600 hover:bg-red-100'
  };
  const sizes = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-4 py-2 text-sm',
    lg: 'px-5 py-3 text-sm font-bold'
  };
  
  return (
    <button 
      className={cn(
        'inline-flex items-center justify-center rounded-xl font-semibold transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none',
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    />
  );
};

const Input = ({ className, ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input 
    className={cn(
      'w-full px-4 py-2 bg-transparent outline-none text-sm',
      className
    )}
    {...props}
  />
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [accessCode, setAccessCode] = useState('');
  const [loginError, setLoginError] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currUser) => {
      setUser(currUser);
      setLoading(false);
      
      if (currUser) {
        // Sync user profile
        const userRef = doc(db, 'users', currUser.uid);
        setDoc(userRef, {
          displayName: currUser.displayName || 'Anonymous',
          photoURL: currUser.photoURL || null,
          lastSeen: serverTimestamp()
        }, { merge: true });
      }
    });
    return unsubscribe;
  }, []);

  // 1. Fitur Auto Logout (Inactivity Timer)
  useEffect(() => {
    if (!user) return;

    let timeout: NodeJS.Timeout;
    
    const resetTimer = () => {
      clearTimeout(timeout);
      // Auto logout dalam 60 detik (1 menit)
      timeout = setTimeout(() => {
        console.log("Inactivity detected, logging out...");
        signOut(auth);
      }, 60000); 
    };

    // Listen to user activity
    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keydown', resetTimer);
    window.addEventListener('scroll', resetTimer);
    window.addEventListener('touchstart', resetTimer);

    resetTimer(); // Start timer initially

    return () => {
      clearTimeout(timeout);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keydown', resetTimer);
      window.removeEventListener('scroll', resetTimer);
      window.removeEventListener('touchstart', resetTimer);
    };
  }, [user]);

  // 2. Fetch Rooms (Disederhanakan: Tampilkan semua room agar user baru langsung bisa lihat)
  useEffect(() => {
    if (!user) {
      setRooms([]);
      return;
    }

    // Mengambil semua room yang tersedia di database
    const q = query(
      collection(db, 'rooms').withConverter(roomConverter),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const roomData = snapshot.docs.map(doc => doc.data());
      setRooms(roomData);
    }, (error) => {
      console.error("Fetch Rooms Error:", error);
    });

    return unsubscribe;
  }, [user]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    if (!accessCode.trim()) return;

    try {
      await loginWithCode(accessCode.trim());
    } catch (err: any) {
      setLoginError(err.message || 'Gagal masuk. Coba lagi.');
    }
  };

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newRoomName.trim()) return;

    try {
      await addDoc(collection(db, 'rooms'), {
        name: newRoomName.trim(),
        createdBy: user.uid,
        createdAt: serverTimestamp(),
        members: [user.uid]
      });
      setNewRoomName('');
      setIsCreateModalOpen(false);
    } catch (err) {
      console.error("Create Room Error:", err);
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-[#F3F4F6] font-sans">
        <Loader2 className="w-8 h-8 animate-spin text-gray-300" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-[#F3F4F6] font-sans p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full text-center space-y-8"
        >
          <div className="space-y-4">
            <div className="inline-flex p-4 bg-white rounded-3xl shadow-sm mb-6">
              <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center text-white font-bold text-2xl">
                S
              </div>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-gray-800">Supachat</h1>
            <p className="text-gray-500 leading-relaxed font-sans font-medium text-sm">
              Gunakan kode akses yang diberikan admin untuk masuk.
            </p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative group">
              <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-indigo-600" />
              <input 
                type="password"
                placeholder="Masukkan Kode Akses..." 
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-white border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-100 focus:border-indigo-600 transition-all text-sm font-semibold tracking-widest text-center"
              />
            </div>
            {loginError && <p className="text-xs text-red-500 font-medium">{loginError}</p>}
            <Button 
              type="submit"
              size="lg" 
              className="w-full bg-indigo-600 shadow-lg shadow-indigo-200 hover:bg-indigo-700 h-12"
              disabled={!accessCode.trim()}
            >
              Masuk Sekarang
            </Button>
          </form>
          
          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">
            Private Access • End-to-End Control
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full flex bg-[#F3F4F6] font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-white font-bold">
              S
            </div>
            <h1 className="font-bold text-xl tracking-tight text-gray-800">Supachat</h1>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsCreateModalOpen(true)} className="p-1.5 rounded-full text-gray-400">
            <Plus className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-1">
          <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 px-2 flex items-center justify-between">
            <span>Daftar Obrolan</span>
            <div className="flex items-center gap-1 text-emerald-500">
              <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
              Live
            </div>
          </div>
          {rooms.map(room => (
            <motion.div
              key={room.id}
              onClick={() => setActiveRoomId(room.id)}
              className={cn(
                "flex items-center gap-3 p-3 rounded-xl cursor-pointer font-semibold transition-all group",
                activeRoomId === room.id 
                  ? "bg-emerald-500 text-white shadow-lg shadow-emerald-100" 
                  : "text-gray-500 hover:bg-gray-50 hover:text-gray-900"
              )}
            >
              <Hash className={cn(
                "w-4 h-4",
                activeRoomId === room.id ? "text-emerald-100" : "text-gray-300"
              )} />
              <span className="truncate flex-1 text-sm">{room.name}</span>
              {activeRoomId === room.id && (
                <div className="w-1.5 h-1.5 bg-white rounded-full" />
              )}
            </motion.div>
          ))}
          {rooms.length === 0 && (
            <div className="px-6 py-12 text-center space-y-3">
              <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center mx-auto text-gray-300">
                <MessageSquare className="w-6 h-6" />
              </div>
              <p className="text-xs text-gray-400 font-medium leading-relaxed">
                Belum ada room nih.<br/>Buat yang baru di atas!
              </p>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-gray-100 bg-gray-50/50">
           <div className="bg-white border border-gray-100 rounded-2xl p-3 flex items-center gap-3 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-xs shadow-inner overflow-hidden flex-shrink-0">
              {user.photoURL ? (
                <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
              ) : (
                <span>{user.displayName?.charAt(0) || 'U'}</span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-gray-900 truncate">{user.displayName}</p>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-tighter">Auto-Logout 1m</span>
                <span className="text-[10px] text-gray-300">|</span>
                <button 
                  onClick={() => signOut(auth)}
                  className="text-[11px] font-bold text-gray-400 hover:text-red-500 transition-colors"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col bg-white overflow-hidden">
        {activeRoomId ? (
          <ChatWindow 
            roomId={activeRoomId} 
            user={user} 
            roomName={rooms.find(r => r.id === activeRoomId)?.name || ''} 
          />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center space-y-4 p-8 text-center bg-gray-50/30">
            <div className="w-16 h-16 bg-white rounded-3xl shadow-sm flex items-center justify-center mb-4 border border-gray-100">
              <MessageSquare className="w-8 h-8 text-emerald-500" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Select a Room</h3>
            <p className="text-sm text-gray-500 max-w-xs">
              Choose a conversation from the sidebar to begin chatting.
            </p>
          </div>
        )}

        {/* Create Room Modal */}
        <AnimatePresence>
          {isCreateModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/20 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-[2rem] p-8 w-full max-w-md shadow-2xl space-y-6"
              >
                <div className="space-y-4 items-center flex flex-col text-center">
                  <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center text-white font-bold text-2xl mb-2">
                    S
                  </div>
                  <div className="space-y-1">
                    <h2 className="text-2xl font-bold tracking-tight text-gray-800">New Room</h2>
                    <p className="text-sm text-gray-500">Buat ruang obrolan baru di Supachat.</p>
                  </div>
                </div>
                <form onSubmit={handleCreateRoom} className="space-y-4">
                  <div className="bg-gray-50 border border-gray-200 rounded-2xl px-4 py-1 focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
                    <Input 
                      placeholder="Contoh: Diskusi Projek, Santai..." 
                      value={newRoomName}
                      onChange={(e) => setNewRoomName(e.target.value)}
                      autoFocus
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" className="flex-1" onClick={() => setIsCreateModalOpen(false)}>
                      Batal
                    </Button>
                    <Button type="submit" className="flex-1" disabled={!newRoomName.trim()}>
                      Buat Room
                    </Button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

// --- Chat Window Sub-component ---

function ChatWindow({ roomId, user, roomName }: { roomId: string, user: User, roomName: string }) {
  const [messages, setMessages] = useState<any[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const [isEmojiOpen, setIsEmojiOpen] = useState(false);

  const emojis = ['😊', '😂', '🔥', '👍', '🙏', '❤️', '🙌', '🎉', '🚀', '✨', '👀', '💡'];

  useEffect(() => {
    setLoading(true);
    const q = query(
      collection(db, 'rooms', roomId, 'messages'),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
      setLoading(false);
      setTimeout(() => {
        const chatEnd = document.getElementById('chat-end');
        chatEnd?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    return unsubscribe;
  }, [roomId]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const text = inputText;
    setInputText('');
    setIsEmojiOpen(false);

    try {
      await addDoc(collection(db, 'rooms', roomId, 'messages'), {
        text,
        senderId: user.uid,
        senderName: user.displayName || 'User',
        senderPhoto: user.photoURL,
        createdAt: serverTimestamp()
      });
    } catch (err) {
      console.error("Send Message Error:", err);
    }
  };

  const handleClearChat = async () => {
    if (!window.confirm('Bersihkan semua pesan di room ini?')) return;
    
    try {
      const q = query(collection(db, 'rooms', roomId, 'messages'));
      const snapshot = await getDocs(q);
      
      const batch = writeBatch(db);
      snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
      });
      await batch.commit();
    } catch (err) {
      console.error("Clear Chat Error:", err);
    }
  };

  const addEmoji = (emoji: string) => {
    setInputText(prev => prev + emoji);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-white relative">
      {/* Chat Header */}
      <header className="h-20 border-b border-gray-100 px-8 flex items-center justify-between flex-shrink-0 bg-white z-10">
        <div className="flex flex-col">
          <h2 className="text-lg font-bold text-gray-800">{roomName}</h2>
          <p className="text-xs text-emerald-500 flex items-center gap-1 font-medium">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
            Private Session • Encrypted
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="danger" 
            size="sm" 
            onClick={() => {
              console.log("Clear chat clicked");
              handleClearChat();
            }} 
            className="px-3" 
            title="Bersihkan Chat"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => alert("Fitur Setting akan segera hadir!")}
          >
            Settings
          </Button>
        </div>
      </header>

      {/* Chat Stream */}
      <div className="flex-1 overflow-y-auto p-8 space-y-6">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-6 h-6 animate-spin text-gray-200" />
          </div>
        ) : (
          messages.map((msg, idx) => {
            const isMe = msg.senderId === user.uid;
            const prevMsg = messages[idx - 1];
            const showMeta = !prevMsg || prevMsg.senderId !== msg.senderId;

            return (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "flex items-start gap-4",
                  isMe ? "flex-row-reverse" : "flex-row"
                )}
              >
                {!isMe && (
                   <div className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden">
                    {msg.senderPhoto && <img src={msg.senderPhoto} className="w-full h-full object-cover" alt="" />}
                   </div>
                )}
                {isMe && (
                   <div className="w-8 h-8 rounded-full bg-indigo-500 flex-shrink-0 flex items-center justify-center text-white text-[10px] font-bold overflow-hidden">
                    {msg.senderPhoto ? <img src={msg.senderPhoto} className="w-full h-full object-cover" alt="" /> : "ME"}
                   </div>
                )}
                
                <div className={cn(
                  "space-y-1 flex flex-col",
                  isMe ? "items-end" : "items-start"
                )}>
                  {showMeta && (
                    <div className={cn(
                      "flex items-baseline gap-2",
                      isMe ? "flex-row-reverse" : "flex-row"
                    )}>
                      <span className="font-bold text-sm text-gray-800">{isMe ? "You" : msg.senderName}</span>
                      {msg.createdAt && (
                        <span className="text-[10px] text-gray-400">
                          {format(msg.createdAt.toDate(), 'HH:mm')}
                        </span>
                      )}
                    </div>
                  )}
                  <div className={cn(
                    "px-4 py-3 rounded-2xl max-w-md text-sm leading-relaxed",
                    isMe 
                      ? "bg-indigo-600 text-white rounded-tr-none shadow-md shadow-indigo-100" 
                      : "bg-gray-100 text-gray-800 rounded-tl-none"
                  )}>
                    {msg.text}
                  </div>
                </div>
              </motion.div>
            )
          })
        )}
        <div id="chat-end" />
      </div>

      {/* Message Input */}
      <div className="p-6">
        <div className="max-w-4xl mx-auto space-y-4">
          <AnimatePresence>
            {isEmojiOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="bg-white border border-gray-200 p-3 rounded-2xl shadow-xl flex flex-wrap gap-2"
              >
                {emojis.map(e => (
                  <button 
                    key={e} 
                    type="button"
                    onClick={() => addEmoji(e)}
                    className="text-xl hover:scale-125 transition-transform p-1"
                  >
                    {e}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
          
          <form onSubmit={handleSendMessage} className="flex items-center gap-3 bg-gray-50 border border-gray-200 p-2 pl-4 rounded-2xl focus-within:ring-2 focus-within:ring-indigo-100 transition-all shadow-sm">
            <button 
              type="button"
              onClick={() => setIsEmojiOpen(!isEmojiOpen)}
              className={cn(
                "p-2 rounded-lg transition-colors",
                isEmojiOpen ? "text-indigo-600 bg-indigo-50" : "text-gray-400 hover:bg-gray-200"
              )}
            >
              <Smile className="w-5 h-5" />
            </button>
            <Input 
              placeholder="Ketik pesan di sini..." 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
            />
            <Button type="submit" disabled={!inputText.trim()} className="px-5">Kirim</Button>
          </form>
        </div>
        <p className="text-center text-[10px] text-gray-400 mt-3 uppercase tracking-widest font-semibold flex items-center justify-center gap-1">
          <ShieldCheck className="w-3 h-3" />
          Secured Session
        </p>
      </div>
    </div>
  );
}
