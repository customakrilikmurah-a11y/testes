import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  signInAnonymously, 
  onAuthStateChanged, 
  User,
  updateProfile
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc,
  getDocFromServer, 
  Timestamp,
  QueryDocumentSnapshot,
  SnapshotOptions
} from 'firebase/firestore';
import firebaseConfig from '@/firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export async function loginWithCode(code: string) {
  try {
    const codeRef = doc(db, 'accessCodes', code);
    console.log(`Mencoba login dengan kode: "${code}" pada database: ${firebaseConfig.firestoreDatabaseId}`);
    
    const codeSnap = await getDocFromServer(codeRef);
    
    if (!codeSnap.exists()) {
      console.warn(`Login gagal: Dokumen "${code}" tidak ditemukan di koleksi "accessCodes".`);
      throw new Error('Kode akses tidak valid. Pastikan Document ID di database sudah sesuai.');
    }

    const { displayName, photoURL } = codeSnap.data();
    const result = await signInAnonymously(auth);
    
    // Update profile with the info from the code
    if (result.user) {
      await updateProfile(result.user, {
        displayName: displayName,
        photoURL: photoURL || null
      });
    }
    
    return result.user;
  } catch (error: any) {
    console.error("Auth Error:", error);
    throw error;
  }
}

export function signOut() {
  return auth.signOut();
}

// Connection check
async function testConnection() {
  try {
    // Basic connectivity check
    await getDocFromServer(doc(db, '_health_check_', 'pulse'));
  } catch (error: any) {
    if (error.message?.includes('the client is offline')) {
      console.error("Firebase is offline. Check your configuration.");
    }
    // We ignore other errors as the _health_check_ doc probably doesn't exist
  }
}
testConnection();

// Types
export interface Room {
  id: string;
  name: string;
  description?: string;
  createdBy: string;
  createdAt: Timestamp;
  members: string[];
}

export interface Message {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  senderPhoto?: string;
  createdAt: Timestamp;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  lastSeen: Timestamp;
}

// Converters
export const roomConverter = {
  toFirestore: (room: Partial<Room>) => room,
  fromFirestore: (snapshot: QueryDocumentSnapshot, options: SnapshotOptions): Room => {
    const data = snapshot.data(options);
    return { id: snapshot.id, ...data } as Room;
  }
};

export const messageConverter = {
  toFirestore: (message: Partial<Message>) => message,
  fromFirestore: (snapshot: QueryDocumentSnapshot, options: SnapshotOptions): Message => {
    const data = snapshot.data(options);
    return { id: snapshot.id, ...data } as Message;
  }
};
